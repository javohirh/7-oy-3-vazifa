import React from "react";

function UserNotFound() {
  return (
    <div className="text-center text-red-700 text-2xl ">
      <h1>You do not Register Yet (:</h1>
      <p>Plese Register</p>
    </div>
  );
}

export default UserNotFound;
