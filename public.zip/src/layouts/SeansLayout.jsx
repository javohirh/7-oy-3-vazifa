import { Outlet } from "react-router-dom";

function Seans() {
  return <Outlet />;
}

export default Seans;
